"""Minimal signaling relay: every message goes to the other peers in the same room (the URL path).
Run: pip install websockets && python server.py"""
import asyncio
import websockets

rooms = {}

async def handler(ws):
    req = getattr(ws, "request", None)
    room = getattr(req, "path", None) or getattr(ws, "path", "/")
    peers = rooms.setdefault(room, set())
    peers.add(ws)
    try:
        async for msg in ws:
            websockets.broadcast(peers - {ws}, msg)
    finally:
        peers.discard(ws)
        if not peers:
            rooms.pop(room, None)

async def main():
    async with websockets.serve(handler, "0.0.0.0", 8765):
        print("Signaling on ws://0.0.0.0:8765/<room>")
        await asyncio.Future()

asyncio.run(main())
