package com.example.streamcontrol

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import okhttp3.*
import org.json.JSONObject
import org.webrtc.*
import java.nio.ByteBuffer

/** Shows the other phone's screen and sends taps, swipes and Back/Home/Recents to it. */
class ViewerActivity : Activity() {
    private lateinit var egl: EglBase
    private lateinit var factory: PeerConnectionFactory
    private lateinit var view: SurfaceViewRenderer
    private lateinit var label: TextView
    private var pc: PeerConnection? = null
    private var dc: DataChannel? = null
    private var ws: WebSocket? = null
    @Volatile private var videoW = 0
    @Volatile private var videoH = 0
    private var down: Pair<Double, Double>? = null
    private var downAt = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions())
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext)).createPeerConnectionFactory()

        view = SurfaceViewRenderer(this)
        view.init(egl.eglBaseContext, object : RendererCommon.RendererEvents {
            override fun onFirstFrameRendered() { runOnUiThread { label.visibility = android.view.View.GONE } }
            override fun onFrameResolutionChanged(w: Int, h: Int, rotation: Int) { videoW = w; videoH = h }
        })
        view.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT)
        view.setOnTouchListener { _, e -> onTouch(e); true }

        label = TextView(this).apply { text = "Connecting…"; setTextColor(Color.WHITE); textSize = 18f }
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(view, FrameLayout.LayoutParams(-1, -1))
            addView(label, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf("Back" to "back", "Home" to "home", "Recents" to "recents").forEach { (t, a) ->
                addView(Button(this@ViewerActivity).apply { text = t; setOnClickListener { sendCtl(JSONObject().put("t", "nav").put("a", a)) } },
                    LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(frame, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar, LinearLayout.LayoutParams(-1, -2))
        })

        runCatching {
            val url = wsUrl(intent.getStringExtra("addr")!!, intent.getStringExtra("code")!!)
            ws = OkHttpClient().newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
                override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send("""{"type":"hello"}""") }
                override fun onMessage(webSocket: WebSocket, text: String) = onSignal(JSONObject(text))
                override fun onFailure(webSocket: WebSocket, t: Throwable, r: Response?) { say("Could not connect. Check the address and code.") }
            })
        }.onFailure { say("That address does not look right.") }
    }

    private fun say(t: String) = runOnUiThread { label.text = t; label.visibility = android.view.View.VISIBLE }
    private fun send(o: JSONObject) { ws?.send(o.toString()) }

    private fun onSignal(m: JSONObject) {
        when (m.getString("type")) {
            "offer" -> {
                dc?.close(); pc?.close()
                val cfg = PeerConnection.RTCConfiguration(listOf(
                    PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()))
                cfg.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
                val p = factory.createPeerConnection(cfg, object : Peer() {
                    override fun onIceCandidate(c: IceCandidate?) {
                        c ?: return
                        send(JSONObject().put("type", "ice").put("sdpMid", c.sdpMid)
                            .put("sdpMLineIndex", c.sdpMLineIndex).put("candidate", c.sdp))
                    }
                    override fun onDataChannel(d: DataChannel?) { dc = d }
                    override fun onTrack(t: RtpTransceiver?) { (t?.receiver?.track() as? VideoTrack)?.addSink(view) }
                    override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                        if (s == PeerConnection.IceConnectionState.FAILED || s == PeerConnection.IceConnectionState.DISCONNECTED)
                            say("Connection lost.")
                    }
                })!!
                pc = p
                p.setRemoteDescription(object : Sdp() {
                    override fun onSetSuccess() {
                        p.createAnswer(object : Sdp() {
                            override fun onCreateSuccess(d: SessionDescription?) {
                                d ?: return
                                p.setLocalDescription(Sdp(), d)
                                send(JSONObject().put("type", "answer").put("sdp", d.description))
                            }
                        }, MediaConstraints())
                    }
                }, SessionDescription(SessionDescription.Type.OFFER, m.getString("sdp")))
            }
            "ice" -> pc?.addIceCandidate(IceCandidate(m.getString("sdpMid"), m.getInt("sdpMLineIndex"), m.getString("candidate")))
        }
    }

    private fun sendCtl(o: JSONObject) {
        val d = dc ?: return
        if (d.state() == DataChannel.State.OPEN) d.send(DataChannel.Buffer(ByteBuffer.wrap(o.toString().toByteArray()), false))
    }

    // Convert a touch to 0..1 fractions of the video frame (the frame is letterboxed inside the view).
    private fun norm(x: Float, y: Float): Pair<Double, Double>? {
        if (videoW == 0 || videoH == 0) return null
        val s = minOf(view.width.toFloat() / videoW, view.height.toFloat() / videoH)
        val dw = videoW * s; val dh = videoH * s
        val nx = ((x - (view.width - dw) / 2) / dw).toDouble().coerceIn(0.0, 1.0)
        val ny = ((y - (view.height - dh) / 2) / dh).toDouble().coerceIn(0.0, 1.0)
        return Pair(nx, ny)
    }

    private fun onTouch(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = norm(e.x, e.y); downAt = e.eventTime }
            MotionEvent.ACTION_UP -> {
                val a = down; val b = norm(e.x, e.y); down = null
                if (a == null || b == null) return
                val moved = Math.hypot(b.first - a.first, b.second - a.second) > 0.015
                sendCtl(if (moved) JSONObject().put("t", "swipe").put("x1", a.first).put("y1", a.second)
                        .put("x2", b.first).put("y2", b.second).put("ms", maxOf(100L, e.eventTime - downAt))
                    else JSONObject().put("t", "tap").put("x", a.first).put("y", a.second))
            }
            MotionEvent.ACTION_CANCEL -> down = null
        }
    }

    override fun onDestroy() {
        ws?.close(1000, null)
        runCatching { dc?.close(); pc?.close(); view.release(); egl.release() }
        super.onDestroy()
    }
}
