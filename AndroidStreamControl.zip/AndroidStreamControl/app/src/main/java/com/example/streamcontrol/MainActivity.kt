package com.example.streamcontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var server: EditText
    private lateinit var status: TextView
    private lateinit var btn: Button
    private lateinit var addr: EditText
    private lateinit var code: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        val pad = (24 * resources.displayMetrics.density).toInt()
        fun title(t: String) = TextView(this).apply { text = t; textSize = 20f; setPadding(0, pad, 0, pad / 3) }

        server = EditText(this).apply { hint = "Server (leave blank to host on this Wi-Fi)"; setSingleLine() }
        btn = Button(this).apply { setOnClickListener { onMain() } }
        status = TextView(this).apply { setPadding(0, pad / 2, 0, 0) }
        addr = EditText(this).apply { hint = "Address, e.g. 192.168.1.5:8765"; setSingleLine() }
        code = EditText(this).apply { hint = "Code"; inputType = InputType.TYPE_CLASS_NUMBER }
        val connect = Button(this).apply {
            text = "Connect and control"
            setOnClickListener {
                val a = addr.text.toString().trim(); val c = code.text.toString().trim()
                if (a.isEmpty() || c.isEmpty())
                    Toast.makeText(this@MainActivity, "Enter the address and code shown on the other phone.", Toast.LENGTH_LONG).show()
                else startActivity(Intent(this@MainActivity, ViewerActivity::class.java).putExtra("addr", a).putExtra("code", c))
            }
        }
        setContentView(ScrollView(this).apply {
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(pad, pad * 2, pad, pad)
                addView(title("Share this phone")); addView(server); addView(btn); addView(status)
                addView(title("Control another phone")); addView(addr); addView(code); addView(connect)
            })
        })
    }

    override fun onResume() { super.onResume(); refresh() }

    // Grey = control permission missing, white = ready, green = sharing.
    private fun refresh() {
        val allowed = ControlService.instance != null
        val on = StreamService.running
        btn.text = when { !allowed -> "Allow remote control"; on -> "Stop sharing"; else -> "Start sharing" }
        btn.backgroundTintList = ColorStateList.valueOf(
            when { !allowed -> Color.LTGRAY; on -> Color.rgb(46, 160, 67); else -> Color.WHITE })
        status.text = when {
            !allowed -> "Turn on Stream Control in Accessibility settings, then come back."
            on -> {
                val where = server.text.toString().trim().ifEmpty { "${localIp() ?: "(connect to Wi-Fi first)"}:$PORT" }
                "Sharing. On the other phone, under Control another phone, enter:\nAddress: $where\nCode: ${StreamService.roomCode}"
            }
            else -> "Ready. Start sharing to get a code for the other phone."
        }
    }

    private fun onMain() {
        when {
            ControlService.instance == null -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            StreamService.running -> { stopService(Intent(this, StreamService::class.java)); btn.postDelayed({ refresh() }, 300) }
            else -> startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 7)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 7 && res == RESULT_OK && data != null) {
            val c = (10_000_000..99_999_999).random().toString()   // 8 digits, new each session
            StreamService.roomCode = c
            startForegroundService(Intent(this, StreamService::class.java)
                .putExtra("data", data).putExtra("url", server.text.toString().trim()).putExtra("code", c))
            btn.postDelayed({ refresh() }, 500)
        }
    }
}
