package com.example.streamcontrol

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import okhttp3.*
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import java.net.InetSocketAddress
import java.net.NetworkInterface
import org.json.JSONObject
import org.webrtc.*

/** Captures the screen, streams it over WebRTC, and applies control messages from the viewer. */
class StreamService : Service() {
    companion object {
        @Volatile var running = false
        @Volatile var roomCode: String? = null
    }

    private lateinit var egl: EglBase
    private lateinit var factory: PeerConnectionFactory
    private var capturer: ScreenCapturerAndroid? = null
    private var helper: SurfaceTextureHelper? = null
    private var source: VideoSource? = null
    private var track: VideoTrack? = null
    private var pc: PeerConnection? = null
    private var dc: DataChannel? = null
    private var ws: WebSocket? = null
    private var relay: WebSocketServer? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("share", "Screen sharing", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, "share").setContentTitle("Your screen is being shared")
            .setSmallIcon(android.R.drawable.ic_menu_share).setOngoing(true).build()
        // Must run before the projection is used (Android 14+).
        startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        running = true
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        val code = i?.getStringExtra("code")
        if (data == null || code == null) { stopSelf(); return START_NOT_STICKY }
        // Blank server = this phone hosts the signaling relay for the other phone on the same Wi-Fi.
        val base = i?.getStringExtra("url").orEmpty().trim()
        if (base.isEmpty()) startRelay(code)
        val url = wsUrl(base.ifEmpty { "127.0.0.1:$PORT" }, code)
        startCapture(data)
        ws = OkHttpClient().newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onMessage(webSocket: WebSocket, text: String) = onSignal(JSONObject(text))
            override fun onFailure(webSocket: WebSocket, t: Throwable, r: Response?) { stopSelf() }
        })
        return START_NOT_STICKY
    }

    /** Tiny relay: forwards messages between clients that used the right code in the URL path. */
    private fun startRelay(code: String) {
        val ready = java.util.concurrent.CountDownLatch(1)
        fun ok(c: org.java_websocket.WebSocket) = c.resourceDescriptor.trim('/') == code
        relay = object : WebSocketServer(InetSocketAddress(PORT)) {
            override fun onOpen(c: org.java_websocket.WebSocket, h: ClientHandshake) { if (!ok(c)) c.close() }
            override fun onClose(c: org.java_websocket.WebSocket, n: Int, reason: String?, remote: Boolean) {}
            override fun onMessage(c: org.java_websocket.WebSocket, m: String) {
                if (ok(c)) connections.forEach { if (it !== c && ok(it)) it.send(m) }
            }
            override fun onError(c: org.java_websocket.WebSocket?, e: Exception?) {}
            override fun onStart() { ready.countDown() }
        }.apply { isReuseAddr = true; start() }
        ready.await(2, java.util.concurrent.TimeUnit.SECONDS)
    }

    private fun startCapture(data: Intent) {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).createInitializationOptions())
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl.eglBaseContext)).createPeerConnectionFactory()
        // Downscale the capture: smaller frames mean less lag.
        val dm = resources.displayMetrics
        val s = minOf(1f, 1280f / maxOf(dm.widthPixels, dm.heightPixels))
        val w = (dm.widthPixels * s).toInt() and 1.inv()
        val h = (dm.heightPixels * s).toInt() and 1.inv()
        capturer = ScreenCapturerAndroid(data, object : android.media.projection.MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        })
        helper = SurfaceTextureHelper.create("capture", egl.eglBaseContext)
        source = factory.createVideoSource(true)
        capturer!!.initialize(helper, this, source!!.capturerObserver)
        capturer!!.startCapture(w, h, 30)
        track = factory.createVideoTrack("screen", source)
    }

    private fun send(o: JSONObject) { ws?.send(o.toString()) }

    private fun onSignal(m: JSONObject) {
        when (m.getString("type")) {
            "hello" -> startPeer()
            "answer" -> pc?.setRemoteDescription(Sdp(), SessionDescription(SessionDescription.Type.ANSWER, m.getString("sdp")))
            "ice" -> pc?.addIceCandidate(IceCandidate(m.getString("sdpMid"), m.getInt("sdpMLineIndex"), m.getString("candidate")))
        }
    }

    // The phone always makes the offer, whenever a viewer says hello.
    private fun startPeer() {
        dc?.close(); pc?.close()
        val cfg = PeerConnection.RTCConfiguration(listOf(
            PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()))
        val p = factory.createPeerConnection(cfg, object : Peer() {
            override fun onIceCandidate(c: IceCandidate?) {
                c ?: return
                send(JSONObject().put("type", "ice").put("sdpMid", c.sdpMid)
                    .put("sdpMLineIndex", c.sdpMLineIndex).put("candidate", c.sdp))
            }
        })!!
        pc = p
        p.addTrack(track, listOf("screen"))
        dc = p.createDataChannel("control", DataChannel.Init()).also {
            it.registerObserver(object : DataChannel.Observer {
                override fun onBufferedAmountChange(l: Long) {}
                override fun onStateChange() {}
                override fun onMessage(b: DataChannel.Buffer) {
                    val bytes = ByteArray(b.data.remaining()).also { a -> b.data.get(a) }
                    runCatching { control(JSONObject(String(bytes))) }
                }
            })
        }
        p.createOffer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription?) {
                d ?: return
                p.setLocalDescription(Sdp(), d)
                send(JSONObject().put("type", "offer").put("sdp", d.description))
            }
        }, MediaConstraints())
    }

    // Viewer sends positions as 0..1 fractions of the frame, so resolution doesn't matter.
    private fun control(m: JSONObject) {
        val svc = ControlService.instance ?: return
        val dm = resources.displayMetrics
        fun x(k: String) = (m.getDouble(k) * dm.widthPixels).toFloat()
        fun y(k: String) = (m.getDouble(k) * dm.heightPixels).toFloat()
        when (m.getString("t")) {
            "tap" -> svc.gesture(x("x"), y("y"), x("x"), y("y"), 50)
            "swipe" -> svc.gesture(x("x1"), y("y1"), x("x2"), y("y2"), m.optLong("ms", 300))
            "nav" -> svc.nav(m.getString("a"))
        }
    }

    override fun onDestroy() {
        running = false; roomCode = null
        ws?.close(1000, null)
        runCatching { relay?.stop(300) }
        dc?.close(); pc?.close()
        runCatching { capturer?.stopCapture() }
        capturer?.dispose(); source?.dispose(); helper?.dispose()
        super.onDestroy()
    }
}

open class Sdp : SdpObserver {
    override fun onCreateSuccess(d: SessionDescription?) {}
    override fun onSetSuccess() {}
    override fun onCreateFailure(e: String?) {}
    override fun onSetFailure(e: String?) {}
}

open class Peer : PeerConnection.Observer {
    override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
    override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
    override fun onIceConnectionReceivingChange(b: Boolean) {}
    override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
    override fun onIceCandidate(c: IceCandidate?) {}
    override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
    override fun onAddStream(s: MediaStream?) {}
    override fun onRemoveStream(s: MediaStream?) {}
    override fun onDataChannel(d: DataChannel?) {}
    override fun onRenegotiationNeeded() {}
}

const val PORT = 8765

/** "192.168.1.5:8765" + code -> "ws://192.168.1.5:8765/<code>" */
fun wsUrl(addr: String, code: String): String {
    val a = addr.trim().trimEnd('/')
    return (if (a.startsWith("ws")) a else "ws://$a") + "/" + code
}

fun localIp(): String? = NetworkInterface.getNetworkInterfaces().toList()
    .flatMap { it.inetAddresses.toList() }
    .firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }?.hostAddress
