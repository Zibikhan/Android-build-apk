package com.example.streamcontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Turns remote tap/swipe commands into real touch gestures. */
class ControlService : AccessibilityService() {
    companion object { @Volatile var instance: ControlService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun nav(action: String) {
        performGlobalAction(when (action) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            else -> GLOBAL_ACTION_RECENTS
        })
    }

    /** A tap is a swipe that never moves. */
    fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val path = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0, ms.coerceIn(1L, 5000L))
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }
}
