# AndroidStreamControl (phone to phone)

Phone A shares its screen. Phone B sees it and can tap, swipe, and press Back/Home/Recents.
Both phones run this same app (Android 10+).

## Same Wi-Fi (no server needed)
1. Phone A: open the app, tap "Allow remote control" and enable Stream Control in Accessibility.
   Come back, leave Server blank, tap "Start sharing", accept the screen-capture prompt.
   The app shows an Address and an 8-digit Code.
2. Phone B: under "Control another phone", enter that Address and Code, tap "Connect and control".

## Different networks
Run `signaling/server.py` on any reachable machine (`pip install websockets`), put its
address in the Server field on Phone A (e.g. ws://myhost:8765), and use the same address on Phone B.
The code is the room name. Add a TURN server in StreamService.kt/ViewerActivity.kt for strict networks.

A browser viewer is also included (viewer/index.html; room = the code).

Build: open this folder in Android Studio and run on both phones.
Security: only share on networks you trust; the code is sent unencrypted on the signaling channel.
